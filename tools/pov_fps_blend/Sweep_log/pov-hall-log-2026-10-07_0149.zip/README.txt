POV Wheel — Hall sensor log archive
Exported 2026-10-07 01:49:58 (UTC+02:00)
1 display, 11 sessions, 67,688 events

What this is
  Each time a magnet passes one of a display's six Hall sensors (six times a
  revolution) the display logs the moment. The app keeps every such log it has
  ever downloaded and uses it to stitch "Render POV Video". Below, for each
  display: its sessions (one session = from power-up to the next deep sleep)
  and the periods when the image was actually on.

Files
  <display>/<date>_<time>_s<session>.csv — one line per event, opens in any
      spreadsheet. Columns: time (local, phone clock), esp_us (the display's own
      microsecond timer since power-up), seq (record number in the display's
      log), event, arg.
      event: hall = a magnet passed Hall sensor <arg> (0…5);
             lit  = the image switched on (arg 1 = forward, 0 = reverse spin);
             dark = the image switched off.
  <display>/<…>.json — clock sync data for the same session; keep it next to
      the .csv, the app needs it to import the session back.
  <display>/wheel.json — the display's name and measured clock errors.

Importing
  POV Wheel app → long press "Render POV Video" → Import. The archive is MERGED
  into the phone's own: new events are added, nothing already there is replaced,
  and importing the same file twice adds nothing.

================================================================
TEST   (68:EE:8F:43:0C:69)
================================================================
11 sessions, folder "TEST (68_EE_8F_43_0C_69)"

Session ec8096e9 — 2026-10-06 01:29:08 … 01:43:51   (14 min 43 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-06_01-29_sec8096e9.csv
  Display on:
    01:29:09 – 01:43:50   14 min 41 s    ~190 rpm
  On in total: 14 min 25 s   (16,433 Hall events in the session)

Session 9cb2f77d — 2026-10-06 02:00:56 … 02:00:56   (0 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-06_02-00_s9cb2f77d.csv
  Display on: never (spun below the start speed, or only woke up)

Session 005df3d9 — 2026-10-06 02:20:35 … 02:20:35   (0 s)
  Clock: BLE clock pings, ±12 ms
  File:  2026-10-06_02-20_s005df3d9.csv
  Display on: never (spun below the start speed, or only woke up)

Session cae11c03 — 2026-10-06 02:42:40 … 02:49:35   (6 min 56 s)
  Clock: BLE clock pings, ±8 ms
  File:  2026-10-06_02-42_scae11c03.csv
  Display on:
    02:42:40 – 02:45:28   2 min 47 s     ~243 rpm
    02:47:26 – 02:47:40   14 s           ~242 rpm
    02:49:21 – 02:49:34   13 s           ~291 rpm
  On in total: 3 min 12 s   (4,777 Hall events in the session)

Session 8c7a1585 — 2026-10-06 15:09:04 … 15:09:17   (12 s)
  Clock: BLE clock pings, ±12 ms
  File:  2026-10-06_15-09_s8c7a1585.csv
  Display on:
    15:09:05 – 15:09:14   9 s            ~276 rpm
  On in total: 9 s   (255 Hall events in the session)

Session f21cd40d — 2026-10-06 15:45:19 … 16:01:09   (15 min 50 s)
  Clock: BLE clock pings, ±10 ms
  File:  2026-10-06_15-45_sf21cd40d.csv
  Display on:
    15:45:20 – 15:56:01   10 min 41 s    ~261 rpm
    15:57:01 – 16:01:08   4 min 07 s     ~200 rpm
  On in total: 14 min 46 s   (21,664 Hall events in the session)

Session 9904a469 — 2026-10-06 16:17:54 … 16:22:00   (4 min 06 s)
  Clock: BLE clock pings, ±10 ms
  File:  2026-10-06_16-17_s9904a469.csv
  Display on:
    16:17:56 – 16:21:58   4 min 03 s     ~254 rpm
  On in total: 3 min 56 s   (6,029 Hall events in the session)

Session 50b8cc9b — 2026-10-06 16:37:16 … 16:38:19   (1 min 03 s)
  Clock: BLE clock pings, ±12 ms
  File:  2026-10-06_16-37_s50b8cc9b.csv
  Display on:
    16:37:18 – 16:38:17   1 min 00 s     ~273 rpm
  On in total: 59 s   (1,638 Hall events in the session)

Session d5ba3693 — 2026-10-06 19:05:49 … 19:14:50   (9 min 01 s)
  Clock: BLE clock pings, ±8 ms
  File:  2026-10-06_19-05_sd5ba3693.csv
  Display on:
    19:05:51 – 19:08:53   3 min 02 s     ~262 rpm
    19:10:05 – 19:10:32   27 s           ~249 rpm
    19:13:30 – 19:14:39   1 min 08 s     ~283 rpm
  On in total: 4 min 09 s   (6,908 Hall events in the session)

Session f75b3645 — 2026-10-07 01:18:25 … 01:29:16   (10 min 51 s)
  Clock: BLE clock pings, ±11 ms
  File:  2026-10-07_01-18_sf75b3645.csv
  Display on:
    01:18:26 – 01:20:10   1 min 44 s     ~350 rpm
    01:27:22 – 01:27:57   36 s           ~327 rpm
    01:28:14 – 01:29:14   1 min 00 s     ~309 rpm
  On in total: 2 min 40 s   (6,109 Hall events in the session)

Session 000dba05 — 2026-10-07 01:36:26 … 01:38:03   (1 min 36 s)
  Clock: BLE clock pings, ±8 ms
  File:  2026-10-07_01-36_s000dba05.csv
  Display on:
    01:36:27 – 01:38:02   1 min 34 s     ~366 rpm
  On in total: 1 min 25 s   (3,485 Hall events in the session)
