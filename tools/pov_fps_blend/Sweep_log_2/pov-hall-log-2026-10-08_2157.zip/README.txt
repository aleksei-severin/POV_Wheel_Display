POV Wheel — Hall sensor log archive
Exported 2026-10-08 21:57:43 (UTC+02:00)
3 displays, 29 sessions, 56,233 events

What this is
  Each time a magnet passes one of a display's six Hall sensors (six times a
  revolution) the display logs the moment. The app keeps every such log it has
  ever downloaded and uses it to stitch "Render POV Video". Below, for each
  display: its sessions (one session = from power-up to the next deep sleep)
  and the periods when the image was actually on.

Files
  <display>/<date>_<time>_s<session>.csv — one line per event, opens in any
      spreadsheet. Columns: time (local, phone clock), esp_us (the display's own
      microsecond timer since power-up), seq (record number in the display's
      log; one record can hold several events), event, arg.
      event: hall = a magnet passed Hall sensor <arg> (0…5);
             lit  = the image switched on (arg 1 = forward, 0 = reverse spin);
             dark = the image switched off.
  <display>/<…>.json — clock sync data for the same session; keep it next to
      the .csv, the app needs it to import the session back.
  <display>/wheel.json — the display's name and measured clock errors.

Importing
  POV Wheel app → long press "Render POV Video" → Import. The archive is MERGED
  into the phone's own: new events are added, nothing already there is replaced,
  and importing the same file twice adds nothing.

================================================================
Front   (68:EE:8F:43:0C:55)
================================================================
5 sessions, folder "Front (68_EE_8F_43_0C_55)"

Session 4f862ec5 — 2026-10-07 23:20:23 … 23:20:33   (10 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_23-20_s4f862ec5.csv
  Display on:
    23:20:24 – 23:20:27   3 s            ~112 rpm
  On in total: 3 s   (43 Hall events in the session)

Session 1d4864d9 — 2026-10-08 00:30:42 … 00:30:42   (0 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_00-30_s1d4864d9.csv
  Display on: never (spun below the start speed, or only woke up)

Session 39c0ad1d — 2026-10-08 01:01:05 … 01:05:00   (3 min 55 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_01-01_s39c0ad1d.csv
  Display on:
    01:01:08 – 01:01:10   2 s         
    01:01:10 – 01:01:44   35 s           ~191 rpm   reverse spin
    01:02:23 – 01:02:32   8 s            ~201 rpm   reverse spin
    01:03:13 – 01:03:23   10 s           ~188 rpm   reverse spin
    01:03:47 – 01:04:06   18 s           ~209 rpm   reverse spin
    01:04:26 – 01:05:00   35 s           ~188 rpm   reverse spin
  On in total: 1 min 39 s   (2,083 Hall events in the session)

Session e3bf2005 — 2026-10-08 01:05:15 … 01:05:41   (25 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_01-05_se3bf2005.csv
  Display on:
    01:05:16 – 01:05:17   1 s         
    01:05:18 – 01:05:41   23 s           ~207 rpm   reverse spin
  On in total: 23 s   (505 Hall events in the session)

Session af028d23 — 2026-10-08 21:32:41 … 21:37:49   (5 min 08 s)
  Clock: BLE clock pings, ±11 ms
  File:  2026-10-08_21-32_saf028d23.csv
  Display on:
    21:32:42 – 21:32:42   1 s         
    21:32:43 – 21:33:36   53 s           ~217 rpm   reverse spin
    21:33:53 – 21:34:09   17 s           ~221 rpm   reverse spin
    21:34:29 – 21:34:48   19 s           ~209 rpm   reverse spin
    21:35:20 – 21:35:48   28 s           ~200 rpm   reverse spin
    21:36:11 – 21:36:42   31 s           ~210 rpm   reverse spin
    21:37:14 – 21:37:42   28 s           ~222 rpm   reverse spin
  On in total: 2 min 35 s   (3,812 Hall events in the session)

================================================================
Rear   (3C:0F:02:F5:35:85)
================================================================
3 sessions, folder "Rear (3C_0F_02_F5_35_85)"

Session 313a9647 — 2026-10-08 02:07:58 … 02:07:58   (0 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_02-07_s313a9647.csv
  Display on: never (spun below the start speed, or only woke up)

Session ab3073bb — 2026-10-08 12:16:18 … 12:16:18   (0 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_12-16_sab3073bb.csv
  Display on: never (spun below the start speed, or only woke up)

Session 68c3cc6b — 2026-10-08 19:27:51 … 19:27:51   (0 s)
  Clock: BLE clock pings, ±6 ms
  File:  2026-10-08_19-27_s68c3cc6b.csv
  Display on: never (spun below the start speed, or only woke up)

================================================================
TEST   (68:EE:8F:43:0C:69)
================================================================
21 sessions, folder "TEST (68_EE_8F_43_0C_69)"

Session 72adeb61 — 2026-10-07 21:50:55 … 21:51:02   (7 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_21-50_s72adeb61.csv
  Display on:
    21:50:57 – 21:51:02   5 s            ~216 rpm   (log ends while on)
  On in total: 5 s   (117 Hall events in the session)

Session 2d3e5d51 — 2026-10-07 21:51:03 … 21:54:13   (3 min 10 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_21-51_s2d3e5d51.csv
  Display on:
    21:51:04 – 21:54:10   3 min 06 s     ~250 rpm
  On in total: 3 min 03 s   (4,622 Hall events in the session)

Session fddc113d — 2026-10-07 22:33:18 … 22:39:21   (6 min 02 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_22-33_sfddc113d.csv
  Display on:
    22:33:21 – 22:39:19   5 min 58 s     ~211 rpm
  On in total: 5 min 16 s   (7,453 Hall events in the session)

Session 3f6a83b7 — 2026-10-07 23:04:46 … 23:04:48   (1 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_23-04_s3f6a83b7.csv
  Display on: never (spun below the start speed, or only woke up)

Session fe7016c1 — 2026-10-07 23:16:20 … 23:16:36   (15 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_23-16_sfe7016c1.csv
  Display on:
    23:16:21 – 23:16:36   14 s           ~244 rpm   (log ends while on)
  On in total: 14 s   (357 Hall events in the session)

Session 37ebdb3f — 2026-10-07 23:17:38 … 23:17:44   (6 s)
  Clock: wheel clock, drift corrected, ±156 ms
  File:  2026-10-07_23-17_s37ebdb3f.csv
  Display on:
    23:17:39 – 23:17:44   5 s            ~243 rpm
  On in total: 5 s   (138 Hall events in the session)

Session 8b4951a3 — 2026-10-07 23:17:53 … 23:19:35   (1 min 42 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_23-17_s8b4951a3.csv
  Display on:
    23:17:54 – 23:19:35   1 min 41 s     ~243 rpm   (log ends while on)
  On in total: 1 min 41 s   (2,462 Hall events in the session)

Session d0d6ad6f — 2026-10-07 23:20:24 … 23:20:38   (14 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-07_23-20_sd0d6ad6f.csv
  Display on:
    23:20:25 – 23:20:37   11 s           ~217 rpm
  On in total: 11 s   (258 Hall events in the session)

Session 8b5ad227 — 2026-10-07 23:30:23 … 23:30:32   (9 s)
  Clock: wheel clock, drift corrected, ±156 ms
  File:  2026-10-07_23-30_s8b5ad227.csv
  Display on:
    23:30:24 – 23:30:31   7 s            ~222 rpm
  On in total: 7 s   (160 Hall events in the session)

Session 4731ef53 — 2026-10-08 00:34:22 … 00:34:55   (33 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_00-34_s4731ef53.csv
  Display on:
    00:34:23 – 00:34:54   31 s           ~310 rpm
  On in total: 31 s   (973 Hall events in the session)

Session 30177c03 — 2026-10-08 00:51:11 … 00:51:15   (5 s)
  Clock: wheel clock, drift corrected, ±156 ms
  File:  2026-10-08_00-51_s30177c03.csv
  Display on:
    00:51:12 – 00:51:15   4 s            ~273 rpm   (log ends while on)
  On in total: 4 s   (104 Hall events in the session)

Session aa2e6063 — 2026-10-08 00:51:22 … 00:51:37   (15 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_00-51_saa2e6063.csv
  Display on:
    00:51:23 – 00:51:36   13 s           ~242 rpm
  On in total: 13 s   (319 Hall events in the session)

Session 15a55e91 — 2026-10-08 00:59:53 … 01:05:51   (5 min 57 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_00-59_s15a55e91.csv
  Display on:
    00:59:55 – 01:01:44   1 min 49 s     ~248 rpm
    01:02:44 – 01:03:23   40 s           ~247 rpm
    01:03:47 – 01:04:06   19 s           ~250 rpm
    01:04:26 – 01:05:50   1 min 24 s     ~247 rpm
  On in total: 3 min 57 s   (6,276 Hall events in the session)

Session 3516dae9 — 2026-10-08 11:56:44 … 12:07:21   (10 min 37 s)
  Clock: wheel clock, ±20 ms
  File:  2026-10-08_11-56_s3516dae9.csv
  Display on:
    12:02:20 – 12:02:48   29 s           ~271 rpm
    12:02:59 – 12:07:20   4 min 21 s     ~279 rpm
  On in total: 4 min 32 s   (8,088 Hall events in the session)

Session 880092b9 — 2026-10-08 14:57:47 … 15:00:16   (2 min 29 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_14-57_s880092b9.csv
  Display on:
    14:57:49 – 15:00:15   2 min 26 s     ~220 rpm
  On in total: 2 min 09 s   (3,242 Hall events in the session)

Session 30ad58c7 — 2026-10-08 15:06:21 … 15:06:43   (22 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_15-06_s30ad58c7.csv
  Display on:
    15:06:22 – 15:06:42   20 s           ~311 rpm
  On in total: 17 s   (641 Hall events in the session)

Session 88581675 — 2026-10-08 15:10:42 … 15:12:04   (1 min 21 s)
  Clock: wheel clock, ±20 ms
  File:  2026-10-08_15-10_s88581675.csv
  Display on:
    15:10:44 – 15:12:03   1 min 19 s     ~250 rpm
  On in total: 1 min 05 s   (1,864 Hall events in the session)

Session 61325faf — 2026-10-08 15:27:45 … 15:32:39   (4 min 54 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_15-27_s61325faf.csv
  Display on:
    15:27:46 – 15:27:52   6 s            ~237 rpm
    15:28:39 – 15:29:02   23 s           ~254 rpm
    15:32:30 – 15:32:36   6 s            ~245 rpm
  On in total: 24 s   (694 Hall events in the session)

Session 4c9936b7 — 2026-10-08 16:27:26 … 16:27:42   (16 s)
  Clock: wheel clock, drift corrected, ±50 ms
  File:  2026-10-08_16-27_s4c9936b7.csv
  Display on:
    16:27:27 – 16:27:41   14 s           ~196 rpm
  On in total: 12 s   (278 Hall events in the session)

Session 2ae858dd — 2026-10-08 17:12:21 … 17:17:50   (5 min 29 s)
  Clock: BLE clock pings, ±11 ms
  File:  2026-10-08_17-12_s2ae858dd.csv
  Display on:
    17:12:22 – 17:17:50   5 min 28 s     ~55 rpm
  On in total: 5 min 03 s   (1,860 Hall events in the session)

Session 48bbfffb — 2026-10-08 17:33:00 … 17:40:17   (7 min 17 s)
  Clock: BLE clock pings, ±8 ms
  File:  2026-10-08_17-33_s48bbfffb.csv
  Display on:
    17:33:02 – 17:40:14   7 min 12 s     ~194 rpm
  On in total: 6 min 20 s   (8,527 Hall events in the session)
